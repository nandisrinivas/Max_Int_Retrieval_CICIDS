import os
import sys
import pdb
import torch
import numpy as np
import pickle as pkl
from PIL import Image
from random import shuffle
import cv2
import numpy as np
import tensorflow as tf
import glob
import pandas as pd

from torchvision import datasets, transforms
from sklearn import preprocessing

class kddcup99_train:
    """
    Class for the kddcup99 intrusion detection dataset.
    """
    def __init__(self):
        # Load kddcup99 data
        self.data_list =[ ]
        self.label_list =[ ]
        col_names = ["Destination Port","Flow Duration","Total Fwd Packets","Total Backward Packets","Total Length of Fwd Packets",
             "Total Length of Bwd Packets","Fwd Packet Length Max","Fwd Packet Length Min","Fwd Packet Length Mean",
             "Fwd Packet Length Std","Bwd Packet Length Max","Bwd Packet Length Min","Bwd Packet Length Mean",
             "Bwd Packet Length Std","Flow Bytes/s","Flow Packets/s","Flow IAT Mean","Flow IAT Std",                    
             "Flow IAT Max","Flow IAT Min","Fwd IAT Total","Fwd IAT Mean","Fwd IAT Std","Fwd IAT Max",                     
             "Fwd IAT Min","Bwd IAT Total","Bwd IAT Mean","Bwd IAT Std","Bwd IAT Max","Bwd IAT Min",                     
             "Fwd PSH Flags","Bwd PSH Flags","Fwd URG Flags","Bwd URG Flags","Fwd Header Length","Bwd Header Length",
             "Fwd Packets/s","Bwd Packets/s","Min Packet Length","Max Packet Length","Packet Length Mean","Packet Length Std",               
             "Packet Length Variance","FIN Flag Count","SYN Flag Count","RST Flag Count","PSH Flag Count","ACK Flag Count",                 
             "URG Flag Count","CWE Flag Count","ECE Flag Count","Down/Up Ratio","Average Packet Size","Avg Fwd Segment Size",           
             "Avg Bwd Segment Size","Fwd Header Length.1","Fwd Avg Bytes/Bulk","Fwd Avg Packets/Bulk","Fwd Avg Bulk Rate",              
             "Bwd Avg Bytes/Bulk","Bwd Avg Packets/Bulk","Bwd Avg Bulk Rate","Subflow Fwd Packets","Subflow Fwd Bytes",              
             "Subflow Bwd Packets","Subflow Bwd Bytes","Init_Win_bytes_forward","Init_Win_bytes_backward","act_data_pkt_fwd",               
             "min_seg_size_forward","Active Mean","Active Std","Active Max","Active Min","Idle Mean","Idle Std",                       
             "Idle Max","Idle Min","Label"]                          
        print("loading data")
        attack_int=0
        df1 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",header=None,names = col_names)
        df2 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",header=None,names = col_names)
        df3 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Morning.pcap_ISCX.csv",header=None,names = col_names)
        df4 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Monday-WorkingHours.pcap_ISCX.csv",header=None,names = col_names)
        df5 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",header=None,names = col_names)
        df6 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",header=None,names = col_names)
        df7 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Tuesday-WorkingHours.pcap_ISCX.csv",header=None,names = col_names)
        df8 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Wednesday-workingHours.pcap_ISCX.csv",header=None,names = col_names)
        data = pd.concat([df1,df2])
        del df1,df2
        data = pd.concat([data,df3])
        del df3
        data = pd.concat([data,df4])
        del df4
        data = pd.concat([data,df5])
        del df5
        data = pd.concat([data,df6])
        del df6
        data = pd.concat([data,df7])
        del df7
        data = pd.concat([data,df8])
        del df8
        print(data.tail())
        print(list(data))
        data_without_label=data.iloc[:,0:78]
        print(list(data_without_label))
        print(data_without_label.tail())
        datadnp=data_without_label.to_numpy()
        print("--------------------------------------------data for features-------------------------------------------------------------")
        print(datadnp)
        print("---------------------------------------------end---------------------------------------------------------------------------")
        for i,lab in enumerate (data['Label']):
            if lab=='BENIGN':
                np_array=np.asarray(datadnp[attack_int],dtype=float)
                self.data_list.append(np_array)
                self.label_list.append(0)
                attack_int+=1
            elif lab=='DDoS':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Bot':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='PortScan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1 
            elif lab=='Infiltration':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1 
            elif lab=='Web Attack � Brute Force':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Web Attack � XSS':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Web Attack � Sql Injection':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            else: attack_int+=1
        print(attack_int)
        self.data_list=torch.tensor(self.data_list)
        self.data_list=self.data_list.byte()
        self.label_list = torch.from_numpy(np.array(self.label_list, dtype=int))
        print(self.data_list)
        print(self.data_list.shape)
        print(self.data_list.dtype)
        print(self.label_list)
        print(self.label_list.shape)
        print(self.label_list.dtype)
    def __list__(self):
        return list(self.data_list),list(self.label_list)

class kddcup99_test:
    """
    Class for the kddcup99 intrusion detection dataset.
    """
    def __init__(self):
        # Load kddcup99 data
        self.data_list =[ ]
        self.label_list =[ ]
        col_names = ["Destination Port","Flow Duration","Total Fwd Packets","Total Backward Packets","Total Length of Fwd Packets",
             "Total Length of Bwd Packets","Fwd Packet Length Max","Fwd Packet Length Min","Fwd Packet Length Mean",
             "Fwd Packet Length Std","Bwd Packet Length Max","Bwd Packet Length Min","Bwd Packet Length Mean",
             "Bwd Packet Length Std","Flow Bytes/s","Flow Packets/s","Flow IAT Mean","Flow IAT Std",                    
             "Flow IAT Max","Flow IAT Min","Fwd IAT Total","Fwd IAT Mean","Fwd IAT Std","Fwd IAT Max",                     
             "Fwd IAT Min","Bwd IAT Total","Bwd IAT Mean","Bwd IAT Std","Bwd IAT Max","Bwd IAT Min",                     
             "Fwd PSH Flags","Bwd PSH Flags","Fwd URG Flags","Bwd URG Flags","Fwd Header Length","Bwd Header Length",
             "Fwd Packets/s","Bwd Packets/s","Min Packet Length","Max Packet Length","Packet Length Mean","Packet Length Std",               
             "Packet Length Variance","FIN Flag Count","SYN Flag Count","RST Flag Count","PSH Flag Count","ACK Flag Count",                 
             "URG Flag Count","CWE Flag Count","ECE Flag Count","Down/Up Ratio","Average Packet Size","Avg Fwd Segment Size",           
             "Avg Bwd Segment Size","Fwd Header Length.1","Fwd Avg Bytes/Bulk","Fwd Avg Packets/Bulk","Fwd Avg Bulk Rate",              
             "Bwd Avg Bytes/Bulk","Bwd Avg Packets/Bulk","Bwd Avg Bulk Rate","Subflow Fwd Packets","Subflow Fwd Bytes",              
             "Subflow Bwd Packets","Subflow Bwd Bytes","Init_Win_bytes_forward","Init_Win_bytes_backward","act_data_pkt_fwd",               
             "min_seg_size_forward","Active Mean","Active Std","Active Max","Active Min","Idle Mean","Idle Std",                       
             "Idle Max","Idle Min","Label"]                          
        print("loading data")
        attack_int=0
        df1 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",header=None,names = col_names)
        df2 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",header=None,names = col_names)
        df3 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Friday-WorkingHours-Morning.pcap_ISCX.csv",header=None,names = col_names)
        df4 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Monday-WorkingHours.pcap_ISCX.csv",header=None,names = col_names)
        df5 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",header=None,names = col_names)
        df6 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",header=None,names = col_names)
        df7 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Tuesday-WorkingHours.pcap_ISCX.csv",header=None,names = col_names)
        df8 = pd.read_csv("/home/srinivas/Desktop/MachineLearningCVE/Wednesday-workingHours.pcap_ISCX.csv",header=None,names = col_names)
        data = pd.concat([df1,df2])
        del df1,df2
        data = pd.concat([data,df3])
        del df3
        data = pd.concat([data,df4])
        del df4
        data = pd.concat([data,df5])
        del df5
        data = pd.concat([data,df6])
        del df6
        data = pd.concat([data,df7])
        del df7
        data = pd.concat([data,df8])
        del df8
        print(data.tail())
        print(list(data))
        data_without_label=data.iloc[:,0:78]
        print(list(data_without_label))
        print(data_without_label.tail())
        datadnp=data_without_label.to_numpy()
        print("--------------------------------------------data for features-------------------------------------------------------------")
        print(datadnp)
        print("---------------------------------------------end---------------------------------------------------------------------------")
        for i,lab in enumerate (data['Label']):
            if lab=='BENIGN':
                np_array=np.asarray(datadnp[attack_int],dtype=float)
                self.data_list.append(np_array)
                self.label_list.append(0)
                attack_int+=1
            elif lab=='DDoS':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Bot':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='PortScan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1 
            elif lab=='Infiltration':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1 
            elif lab=='Web Attack � Brute Force':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Web Attack � XSS':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='Web Attack � Sql Injection':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            else: attack_int+=1
        print(attack_int)
        self.data_list=torch.tensor(self.data_list)
        self.data_list=self.data_list.byte()
        self.label_list = torch.from_numpy(np.array(self.label_list, dtype=int))
        print(self.data_list)
        print(self.data_list.shape)
        print(self.data_list.dtype)
        print(self.label_list)
        print(self.label_list.shape)
        print(self.label_list.dtype)
    def __list__(self):
        return list(self.data_list),list(self.label_list)





""" Template Dataset with Labels """
class XYDataset(torch.utils.data.Dataset):
    def __init__(self, x, y, **kwargs):
        self.x, self.y = x, y

        # this was to store the inverse permutation in permuted_mnist
        # so that we could 'unscramble' samples and plot them
        for name, value in kwargs.items():
            setattr(self, name, value)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        x, y = self.x[idx], self.y[idx]

        if type(x) != torch.Tensor:
            # mini_imagenet
            # we assume it's a path --> load from file
            x = self.transform(Image.open(x).convert('RGB'))
            y = torch.Tensor(1).fill_(y).long().squeeze()
        else:
            x = x.float() / 255.
            y = y.long()


        # for some reason mnist does better \in [0,1] than [-1, 1]
        if self.source == 'kddcup99':
            return x, y
        else:
            return (x - 0.5) * 2, y


""" Template Dataset for Continual Learning """
class CLDataLoader(object):
    def __init__(self, datasets_per_task, args, train=True):
        bs = args.batch_size if train else 64

        self.datasets = datasets_per_task
        self.loaders = [
                torch.utils.data.DataLoader(x, batch_size=bs, shuffle=True, drop_last=train, num_workers=0)
                for x in self.datasets ]

    def __getitem__(self, idx):
        return self.loaders[idx]

    def __len__(self):
        return len(self.loaders)

def get_kddcup99(args):
    args.multiple_heads = False
    args.n_classes = 2
    args.n_tasks = 2 if args.n_tasks==-1 else args.n_tasks
    if 'mem_size' in args:
        args.buffer_size = args.n_tasks * args.mem_size * 2
    args.use_conv = False
    args.input_type = 'continuous'
    args.input_size = 78
    if args.output_loss is None:
        args.output_loss = 'naive_cross_entropy_loss'

    assert args.n_tasks in [5, 10], 'kddcup99 only works with 5 or 10 tasks'
    assert '1.' in str(torch.__version__)[:2], 'Use Pytorch 1.x!'
    k=kddcup99_train()
    train_x=k.data_list
    train_y=k.label_list
    m=kddcup99_test()
    test_x=m.data_list
    test_y=m.label_list
    print("-----------------------train_x------------------------------------------train_y------------------------------------------")
    print(train_x)
    print(train_x.shape)
    print(train_y)
    out_train = [
        (x,y) for (x,y) in sorted(zip(train_x, train_y), key=lambda v : v[1]) ]

    out_test = [
        (x,y) for (x,y) in sorted(zip(test_x, test_y), key=lambda v : v[1]) ]

    train_x, train_y = [
            torch.stack([elem[i] for elem in out_train]) for i in [0,1] ]

    test_x,  test_y  = [
            torch.stack([elem[i] for elem in out_test]) for i in [0,1] ]


    # get indices of class split
    train_idx = [((train_y + i) % 2).argmax() for i in range(2)]
    train_idx = [0]+sorted(train_idx)

    test_idx  = [((test_y + i) % 2).argmax() for i in range(2)]
    test_idx  = [0]+sorted(test_idx)

    train_ds, test_ds = [], []
    skip = 1
    for i in range(0, 2, skip):
        tr_s, tr_e = train_idx[i], train_idx[i + skip]
        te_s, te_e = test_idx[i],  test_idx[i + skip]

        train_ds += [(train_x[tr_s:tr_e], train_y[tr_s:tr_e])]
        test_ds  += [(test_x[te_s:te_e],  test_y[te_s:te_e])]

    train_ds, val_ds = make_valid_from_train(train_ds)

    train_ds = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), train_ds)
    val_ds   = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), val_ds)
    test_ds  = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), test_ds)


    return train_ds, val_ds, test_ds


def make_valid_from_train(dataset, cut=0.95):
    tr_ds, val_ds = [], []
    for task_ds in dataset:
        x_t, y_t = task_ds

        # shuffle before splitting
        perm = torch.randperm(len(x_t))
        x_t, y_t = x_t[perm], y_t[perm]

        split = int(len(x_t) * cut)
        x_tr, y_tr   = x_t[:split], y_t[:split]
        x_val, y_val = x_t[split:], y_t[split:]

        tr_ds  += [(x_tr, y_tr)]
        val_ds += [(x_val, y_val)]

    return tr_ds, val_ds
